print("Bonjour Mesdames et Messieurs, voici l'algorithme de Cesar ")
print('*' * 100)
print("                              LE CODE CESAR  ")
print('*' * 100)
uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
lowercase = 'abcdefghijklmnopqrstuvwxyz'

phrase = input('Entrez votre phrase a encrypter: ')
pas = int(input('Entrez votre pas (valeur pour le decalage): '))

def cesar_encript(clearText, step):
    cipherText = ''

    for letter in clearText:
        if letter in uppercase:
            index = uppercase.index(letter)
            letterEncrypted = uppercase[(index + step) % 26]
            cipherText += letterEncrypted
        elif letter in lowercase:
            index = lowercase.index(letter)
            letterEncrypted = lowercase[(index + step) % 26]
            cipherText += letterEncrypted
        elif letter == ' ':
            cipherText += ' '
    return cipherText

#cipherText = cesar_encript(' le code Cesar est facile à déchiffrer', 12)
phrase_encripte = cesar_encript(phrase, pas)
print(phrase_encripte)

